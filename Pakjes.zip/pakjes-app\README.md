Pakjes - universele pakkettracker (MVP)

Dit is een startproject (boilerplate) voor een universele pakket-tracker die zowel mobiel als web ondersteunt via Expo + React Native Web.

Kenmerken MVP:
- Handmatige trackingnummer invoer
- Automatische carrier-detectie (heuristiek)
- Centraal dashboard met trackinglijst
- Lokale opslag (AsyncStorage / IndexedDB voor web)

Installatie & starten (lokaal):
1) Node.js en npm of yarn installeren
2) In deze map: npm install (of yarn)
3) Expo CLI installeren: npm install -g expo-cli (optioneel)
4) Starten: npm run start

Opmerking:
- Voor echte carrier-integraties (API calls) en push-notificaties is later waarschijnlijk een backend of cloud-functies nodig vanwege CORS en API-keys.
- Dit project bevat eenvoudige mock/logica voor carrier-detectie en lokale opslag; het is bedoeld als MVP-bootstrapping.

Volgende stappen die ik kan doen:
- Barcode/QR scanner toevoegen
- E-mail parsing integratie (achter de schermen)
- Backend / cloud-functies voor realtime polling en notificaties
- Meertaligheid

Laat weten of ik verder moet gaan met het installeren van dependencies en het starten van het dev-server, of dat je eerst aanpassingen wilt.
