import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'pakjes_app_packages_v1';

const Storage = {
  async getAllPackages() {
    try {
      const raw = await AsyncStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.warn('Storage get error', e);
      return [];
    }
  },
  async savePackages(list) {
    try {
      await AsyncStorage.setItem(KEY, JSON.stringify(list));
    } catch (e) {
      console.warn('Storage save error', e);
    }
  }
};

export default Storage;
