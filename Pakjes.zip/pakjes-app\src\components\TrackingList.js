import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

function Item({ item }) {
  return (
    <View style={styles.item}>
      <View style={{ flex: 1 }}>
        <Text style={styles.code}>{item.code} ({item.carrier || 'Onbekend'})</Text>
        <Text style={styles.note}>{item.note}</Text>
        <Text style={styles.status}>{item.status}</Text>
      </View>
      <TouchableOpacity style={styles.button} onPress={() => { /* future: open detail */ }}>
        <Text style={{ color: 'white' }}>Details</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function TrackingList({ packages = [] }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={packages}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <Item item={item} />}
        ListEmptyComponent={<Text style={{ padding: 16 }}>Nog geen pakketten toegevoegd.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 8 },
  item: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderColor: '#eee' },
  code: { fontWeight: '600' },
  note: { color: '#666' },
  status: { marginTop: 6, color: '#333' },
  button: { backgroundColor: '#1e90ff', padding: 8, borderRadius: 6 }
});
