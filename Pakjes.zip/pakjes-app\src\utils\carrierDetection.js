// Eenvoudige heuristieke detectie van carriers op basis van tracking-code patronen.
// Dit is niet compleet — uitbreiden/afstemmen per carrier is aanbevolen.

const patterns = [
  { name: 'Bpost', regex: /^\d{14}$/ },
  { name: 'PostNL', regex: /^(3S|99)[0-9A-Z]{11,}$/i },
  { name: 'DHL', regex: /^(JD|JJD)\d{10,}$/i },
  { name: 'DPD', regex: /^\d{12,14}$/ },
  { name: 'UPS', regex: /^[0-9A-Z]{18}$/i },
  { name: 'FedEx', regex: /^\d{12,15}$/ }
];

export default function detectCarrier(code) {
  if (!code) return null;
  const normalized = code.replace(/\s+/g, '');
  for (const p of patterns) {
    if (p.regex.test(normalized)) return p.name;
  }
  return null;
}
