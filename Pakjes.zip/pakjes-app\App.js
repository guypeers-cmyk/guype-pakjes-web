import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet } from 'react-native';
import AddTracking from './src/components/AddTracking';
import TrackingList from './src/components/TrackingList';
import Storage from './src/services/storage';

export default function App() {
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    (async () => {
      const all = await Storage.getAllPackages();
      setPackages(all || []);
    })();
  }, []);

  const onAdd = async (pkg) => {
    const updated = [pkg, ...packages];
    setPackages(updated);
    await Storage.savePackages(updated);
  };

  const onUpdate = async (updatedPkg) => {
    const updated = packages.map(p => p.id === updatedPkg.id ? updatedPkg : p);
    setPackages(updated);
    await Storage.savePackages(updated);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pakjes - Volg al je zendingen</Text>
      </View>
      <AddTracking onAdd={onAdd} />
      <TrackingList packages={packages} onUpdate={onUpdate} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { padding: 16, backgroundColor: '#1e90ff' },
  title: { color: 'white', fontSize: 18, fontWeight: '600' }
});
