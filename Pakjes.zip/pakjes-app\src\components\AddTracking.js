import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text, Alert } from 'react-native';
import carrierDetect from '../utils/carrierDetection';
import uuid from 'react-native-uuid';

export default function AddTracking({ onAdd }) {
  const [code, setCode] = useState('');
  const [note, setNote] = useState('');

  const handleAdd = () => {
    if (!code.trim()) {
      Alert.alert('Fout', 'Voer een trackingnummer in.');
      return;
    }
    const carrier = carrierDetect(code.trim());
    const pkg = {
      id: uuid.v4(),
      code: code.trim(),
      carrier,
      note,
      status: 'Nieuw',
      history: [],
      createdAt: new Date().toISOString()
    };
    onAdd(pkg);
    setCode('');
    setNote('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Trackingnummer</Text>
      <TextInput style={styles.input} value={code} onChangeText={setCode} placeholder="bv. 3S1234567890" />
      <Text style={styles.label}>Omschrijving (optioneel)</Text>
      <TextInput style={styles.input} value={note} onChangeText={setNote} placeholder="bv. Cadeau van Mark" />
      <Button title="Toevoegen" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 8, marginBottom: 12, borderRadius: 6 },
  label: { marginBottom: 4 }
});
